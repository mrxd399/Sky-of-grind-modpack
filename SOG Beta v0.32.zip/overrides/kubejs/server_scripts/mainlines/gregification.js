ServerEvents.recipes(event => {
    event.recipes.gtceu.compressor('diamondcompressing')
        .itemInputs(
            '4x minecraft:coal_block'
        )
        .itemOutputs(
            'gtceu:tiny_diamond_dust'
        )
        .duration(100)
        .EUt(2)
    
    event.recipes.gtceu.forge_hammer('diamondhammah')
        .itemInputs(
            '4x gtceu:tiny_diamond_dust'
        )
        .itemOutputs(
            'minecraft:diamond'
        )
        .duration(600)
        .EUt(2)

    event.recipes.gtceu.macerator('gypsummacerator')
        .itemInputs(
            '4x exdeorum:dust'
        )
        .itemOutputs(
            'gtceu:gypsum_dust'
        )
        .duration(15)
        .EUt(2)

    event.shaped('gtceu:firebricks', [// arg 1: output
            'ABA', 
            'BCB', // arg 2: the shape (array of strings)
            'ABA'  
          ], {
            A: 'gtceu:firebrick', 
            B: 'gtceu:gypsum_dust',  //arg 3: the mapping object
            C: 'gtceu:concrete_bucket'
          }
          
        )

    event.shaped('gtceu:lp_steam_alloy_smelter', [// arg 1: output
            'ABA', 
            'CDC', // arg 2: the shape (array of strings)
            'AAA'  
          ], {
            A: 'gtceu:bronze_small_fluid_pipe', 
            B: 'minecraft:diamond',  //arg 3: the mapping object
            C: 'minecraft:furnace',
            D: 'gtceu:bronze_brick_casing'
          }
          
        )

    event.shaped('watersources:water_source_tier_1', [// arg 1: output
            'ABA', 
            'C C', // arg 2: the shape (array of strings)
            'ABA'  
          ], {
            A: 'gtceu:firebrick', 
            B: 'minecraft:glass',  //arg 3: the mapping object
            C: 'minecraft:water_bucket'
          }
          
        )
    
    event.recipes.gtceu.coke_oven('sulfur')
        .itemInputs('gtceu:stone_dust')
        .itemOutputs('gtceu:sulfur_dust')
        .outputFluids('exdeorum:witch_water 500')
        .duration(20)
    event.recipes.gtceu.coke_oven('graphite')
        .itemInputs('8x gtceu:raw_coal')
        .itemOutputs('gtceu:graphite_dust')
        .outputFluids('gtceu:creosote 500')
        .duration(60)
    event.recipes.gtceu.arc_furnace('lead')
        .itemInputs('gtceu:raw_tin')
        .inputFluids('gtceu:oxygen 63')
        .itemOutputs('gtceu:raw_lead')
        .duration(60)
        .EUt(4)
    event.recipes.gtceu.arc_furnace('diamond')
        .itemInputs('gtceu:raw_coal')
        .inputFluids('gtceu:oxygen 63')
        .itemOutputs('gtceu:raw_diamond')
        .duration(60)
        .EUt(4)
    event.recipes.gtceu.arc_furnace('silver')
        .itemInputs('minecraft:raw_iron')
        .inputFluids('gtceu:oxygen 63')
        .itemOutputs('gtceu:raw_silver')
        .duration(60)
        .EUt(4)
    event.recipes.gtceu.arc_furnace('zinc')
        .itemInputs('minecraft:raw_gold')
        .inputFluids('gtceu:oxygen 63')
        .itemOutputs('gtceu:raw_sphalerite')
        .duration(60)
        .EUt(4)
    event.recipes.gtceu.arc_furnace('lapis')
        .itemInputs('gtceu:raw_diamond')
        .inputFluids('gtceu:oxygen 63')
        .itemOutputs('gtceu:raw_lapis')
        .duration(60)
        .EUt(4)
    event.shaped('ironfurnaces:iron_furnace', [// arg 1: output
            'AAA', 
            'CBD', // arg 2: the shape (array of strings)
            'AAA'  
          ], {
            A: 'gtceu:iron_plate', 
            C: '#forge:tools/hammers',  //arg 3: the mapping object
            B: 'ironfurnaces:copper_furnace',
            D: '#forge:tools/wrenches'
          }
          
        )
    event.shaped('ironfurnaces:gold_furnace', [// arg 1: output
            'ABA', 
            'BCB', // arg 2: the shape (array of strings)
            'ABA'  
          ], {
            A: 'minecraft:glass', 
            C: 'ironfurnaces:iron_furnace',  //arg 3: the mapping object
            B: 'minecraft:gold_block'
          }
          
        )
    event.recipes.gtceu.assembler('diamond_furnace')
        .itemInputs('4x minecraft:diamond_block', 'ironfurnaces:gold_furnace')
        .itemOutputs('ironfurnaces:diamond_furnace')
        .duration(100)
        .EUt(8)
    event.recipes.gtceu.assembler('emerald_furnace')
        .itemInputs('4x minecraft:emerald_block', 'ironfurnaces:diamond_furnace')
        .itemOutputs('ironfurnaces:emerald_furnace')
        .duration(100)
        .EUt(128)
    event.recipes.gtceu.arc_furnace('quartz')
        .itemInputs('gtceu:raw_silver')
        .inputFluids('gtceu:oxygen 63')
        .itemOutputs('gtceu:raw_nether_quartz')
        .duration(60)
        .EUt(4)
    event.recipes.gtceu.arc_furnace('quartzite')
        .itemInputs('gtceu:raw_nether_quartz')
        .inputFluids('gtceu:nitrogen 63')
        .itemOutputs('gtceu:raw_quartzite')
        .duration(60)
        .EUt(4)
    event.recipes.gtceu.arc_furnace('nickel')
        .itemInputs('minecraft:raw_copper')
        .inputFluids('gtceu:nitrogen 63')
        .itemOutputs('gtceu:raw_nickel')
        .duration(60)
        .EUt(4)
    event.recipes.gtceu.arc_furnace('sapph')
        .itemInputs('gtceu:raw_lapis')
        .inputFluids('gtceu:nitrogen 63')
        .itemOutputs('gtceu:sapphire_gem')
        .duration(60)
        .EUt(4)
    event.recipes.gtceu.centrifuge('cobaltite')
        .itemInputs('8x gtceu:raw_nickel')
        .itemOutputs('2x gtceu:cobaltite_dust')
        .duration(300)
        .EUt(32)
    event.recipes.gtceu.centrifuge('gallium')
        .itemInputs('8x gtceu:raw_sphalerite')
        .itemOutputs('2x gtceu:gallium_dust')
        .duration(300)
        .EUt(32)
    event.recipes.gtceu.alloy_smelter('soularium')
        .itemInputs('8x gtceu:brass_ingot', '8x minecraft:soul_sand')
        .itemOutputs('4x enderio:soularium_ingot')
        .duration(300)
        .EUt(8)
    event.recipes.gtceu.assembler('predictionmatrix')
        .itemInputs('8x gtceu:aluminium_dust', '8x gtceu:gallium_dust', '32x minecraft:glass_pane')
        .itemOutputs('8x hostilenetworks:prediction_matrix')
        .duration(20)
        .EUt(32)
    event.recipes.gtceu.assembler('simchamber')
        .itemInputs('4x gtceu:steel_plate', '2x gtceu:cobaltite_dust', '3x gtceu:phenolic_printed_circuit_board', 'gtceu:basic_electronic_circuit')
        .itemOutputs('hostilenetworks:sim_chamber')
        .duration(100)
        .EUt(32)
    event.recipes.gtceu.assembler('lootchamber')
        .itemInputs('4x gtceu:steel_plate', 'gtceu:gallium_arsenide_dust', '2x gtceu:diode', '3x gtceu:basic_electronic_circuit')
        .itemOutputs('hostilenetworks:loot_fabricator')
        .duration(100)
        .EUt(32)
    event.recipes.gtceu.alloy_smelter('soulsand')
        .itemInputs('8x minecraft:ink_sac', '16x minecraft:sand')
        .itemOutputs('4x minecraft:soul_sand')
        .duration(140)
        .EUt(32)
    event.recipes.gtceu.alloy_smelter('conduitbinder')
        .itemInputs('8x enderio:conduit_binder_composite', '2x enderio:soularium_ingot')
        .itemOutputs('12x enderio:conduit_binder')
        .duration(60)
        .EUt(32)
    event.recipes.gtceu.mixer('pulsatingiron')
        .itemInputs('4x minecraft:iron_ingot', 'gtceu:aluminium_ingot')
        .itemOutputs('3x enderio:pulsating_alloy_ingot')
        .duration(100)
        .EUt(32)
    event.recipes.gtceu.mixer('redstonealloy')
        .itemInputs('4x gtceu:red_alloy_ingot', 'gtceu:lead_ingot')
        .itemOutputs('3x enderio:redstone_alloy_ingot')
        .duration(100)
        .EUt(32)
    event.recipes.gtceu.mixer('conductiveiron')
        .itemInputs('4x minecraft:iron_ingot', '2x gtceu:annealed_copper_ingot', 'gtceu:red_alloy_ingot')
        .itemOutputs('4x enderio:conductive_alloy_ingot')
        .duration(100)
        .EUt(32)
    event.shaped('gtceu:lv_mixer', [// arg 1: output
            'ABA', 
            'ACA', // arg 2: the shape (array of strings)
            'DED'  
          ], {
            A: 'enderio:soularium_ingot', 
            C: 'gtceu:lv_electric_motor',  //arg 3: the mapping object
            B: 'gtceu:tin_rotor',
            D: 'gtceu:basic_electronic_circuit',
            E: 'gtceu:lv_machine_hull'
          }
        )
    event.recipes.gtceu.wiremill('simplecable')
        .itemInputs('2x enderio:conductive_alloy_ingot')
        .itemOutputs('4x storagenetwork:kabel')
        .duration(20)
        .EUt(32)
    event.recipes.gtceu.assembler('master')
        .itemInputs('ironchest:gold_chest', '4x gtceu:basic_electronic_circuit', 'gtceu:lv_machine_hull')
        .itemOutputs('storagenetwork:master')
        .duration(1000)
        .EUt(32) 
    event.recipes.gtceu.assembler('request')
        .itemInputs('8x minecraft:glass', 'gtceu:lv_machine_hull', '4x gtceu:basic_electronic_circuit', 'avaritia:double_compressed_crafting_table')
        .itemOutputs('storagenetwork:request')
        .duration(1000)
        .EUt(32) 
     event.shapeless('minecraft:leather', [ // arg 1: output
            'minecraft:rotten_flesh'
          ])
    event.recipes.gtceu.assembler('upgradebase')
          .itemInputs('16x minecraft:leather', '64x minecraft:string', 'minecraft:iron_block')
          .itemOutputs('sophisticatedbackpacks:upgrade_base')
          .duration(100)
          .EUt(32) 
    event.recipes.gtceu.forge_hammer('dustex')
          .itemInputs('minecraft:sand')
          .itemOutputs('exdeorum:dust')
          .duration(15)
          .EUt(8)     
    event.recipes.gtceu.centrifuge('emerald')
          .itemInputs('8x gtceu:raw_diamond')
          .itemOutputs('2x gtceu:raw_emerald')
          .duration(300)
          .EUt(128) 
    event.recipes.gtceu.centrifuge('rubydust')
          .itemInputs('gtceu:redstone_plate')
          .itemOutputs('8x gtceu:ruby_gem')
          .duration(80)
          .EUt(128) 
    event.recipes.gtceu.centrifuge('vanadium')
          .itemInputs('gtceu:wrought_iron_ingot')
          .itemOutputs('2x gtceu:vanadium_dust')
          .duration(80)
          .EUt(128) 
    event.shaped('gtceu:mv_mixer', [// arg 1: output
            'ABA', 
            'ACA', // arg 2: the shape (array of strings)
            'DED'  
          ], {
            A: 'enderio:soularium_ingot', 
            C: 'gtceu:mv_electric_motor',  //arg 3: the mapping object
            B: 'gtceu:cobalt_brass_gear',
            D: 'gtceu:good_electronic_circuit',
            E: 'gtceu:mv_machine_hull'
          }
        )
    event.recipes.gtceu.arc_furnace('clay')
        .itemInputs('exdeorum:dust')
        .inputFluids('minecraft:water 1000')
        .itemOutputs('minecraft:clay')
        .duration(60)
        .EUt(128)
    event.recipes.gtceu.arc_furnace('watert2')
        .itemInputs('watersources:water_source_tier_1')
        .inputFluids('gtceu:distilled_water 5000')
        .itemOutputs('watersources:water_source_tier_2')
        .duration(800)
        .EUt(128)
    event.recipes.gtceu.centrifuge('manganese')
        .itemInputs('8x gtceu:raw_calcite')
        .itemOutputs('2x gtceu:manganese_dust')
        .duration(80)
        .EUt(128)
    event.shapeless('2x gtceu:rubber_planks', [ // arg 1: output
            'gtceu:rubber_log'
          ])
        event.recipes.gtceu.centrifuge('phosphorus')
          .itemInputs('64x minecraft:glowstone_dust')
          .itemOutputs('8x gtceu:phosphorus_dust')
          .duration(200)
          .EUt(512)
    event.recipes.gtceu.assembler('enderchest')
        .itemInputs('gtceu:hv_super_chest', 'minecraft:ender_eye')
        .inputFluids('gtceu:ender_air 5000')
        .itemOutputs('enderchests:ender_chest')
        .duration(400)
        .EUt(512)
    event.recipes.gtceu.assembler('endertank')
        .itemInputs('gtceu:hv_super_tank', 'minecraft:ender_eye')
        .inputFluids('gtceu:ender_air 5000')
        .itemOutputs('endertanks:ender_tank')
        .duration(200)
        .EUt(512)
    event.recipes.gtceu.mixer('platinum')
        .itemInputs('8x gtceu:silver_dust', '2x gtceu:ender_eye_block', 'enderio:pulsating_alloy_ingot')
        .inputFluids('gtceu:ender_air 5000', 'gtceu:deuterium 1000')
        .itemOutputs('2x gtceu:platinum_dust')
        .duration(100)
        .EUt(512)
    event.recipes.gtceu.arc_furnace('potasio')
        .itemInputs('gtceu:calcite_dust')
        .inputFluids('gtceu:nitrogen_dioxide 63')
        .itemOutputs('2x gtceu:potassium_dust')
        .duration(15)
        .EUt(512)
    event.recipes.gtceu.centrifuge('salt')
        .itemInputs('gtceu:potassium_dust')
        .itemOutputs('8x gtceu:salt_dust')
        .duration(15)
        .EUt(512)
    event.shaped('ae2:controller', [// arg 1: output
            'ABA', 
            'BCB', // arg 2: the shape (array of strings)
            'ADA'  
          ], {
            A: 'gtceu:platinum_ingot', 
            C: 'gtceu:hv_machine_hull',  //arg 3: the mapping object
            B: 'gtceu:lpic_chip',
            D: '#gtceu:circuits/hv'
          }
        )
    event.shaped('bonsaitrees3:bonsaipot', [// arg 1: output
        'AAA', 
        'ABA', // arg 2: the shape (array of strings)
        'AAA'  
      ], {
        A: 'gtceu:firebrick',
        B: 'minecraft:dirt'
      }
    )
    event.recipes.gtceu.cutter('press')
        .itemInputs('16x gtceu:certus_quartz_plate')
        .inputFluids('gtceu:lubricant 1000')
        .itemOutputs('ae2:name_press')
        .duration(2400)
        .EUt(512)
    event.recipes.gtceu.circuit_assembler('engiprocess')
        .itemInputs('ae2:silicon', 'minecraft:redstone', 'minecraft:diamond')
        .inputFluids('gtceu:lubricant 63')
        .notConsumable('ae2:name_press')
        .itemOutputs('ae2:engineering_processor')
        .duration(40)
        .EUt(128)
    event.recipes.gtceu.circuit_assembler('calcprocess')
        .itemInputs('ae2:silicon', 'minecraft:redstone', 'gtceu:certus_quartz_dust')
        .inputFluids('gtceu:lubricant 63')
        .notConsumable('ae2:name_press')
        .itemOutputs('ae2:calculation_processor')
        .duration(40)
        .EUt(128)
    event.recipes.gtceu.circuit_assembler('logicprocess')
        .itemInputs('ae2:silicon', 'minecraft:redstone', 'minecraft:gold_ingot')
        .inputFluids('gtceu:lubricant 63')
        .notConsumable('ae2:name_press')
        .itemOutputs('ae2:logic_processor')
        .duration(40)
        .EUt(128)
    event.recipes.gtceu.mixer('fluix')
        .itemInputs('gtceu:quartzite_gem', 'minecraft:redstone', 'gtceu:certus_quartz_dust')
        .inputFluids('minecraft:water 1000')
        .itemOutputs('3x ae2:fluix_crystal')
        .duration(15)
        .EUt(512)
    event.recipes.gtceu.macerator('fluixdust')
        .itemInputs('ae2:fluix_crystal')
        .itemOutputs('ae2:fluix_dust')
        .duration(15)
        .EUt(512)
    event.recipes.gtceu.alloy_smelter('quartzglass')
        .itemInputs('5x gtceu:certus_quartz_dust', '4x #forge:glass')
        .itemOutputs('4x ae2:quartz_glass')
        .duration(200)
        .EUt(32)
    event.shaped('ae2:cell_component_1k', [// arg 1: output
            'ABA', 
            'BCB', // arg 2: the shape (array of strings)
            'ABA'  
          ], {
            A: 'minecraft:redstone',
            B: 'gtceu:certus_quartz_gem',
            C: '#gtceu:circuits/lv'
          }
        )
    event.shaped('ae2:cell_component_4k', [// arg 1: output
            'ABA', 
            'BCB', // arg 2: the shape (array of strings)
            'ABA'  
          ], {
            A: 'minecraft:redstone',
            B: 'gtceu:certus_quartz_gem',
            C: '#gtceu:circuits/mv'
          }
        )
    event.shaped('ae2:cell_component_16k', [// arg 1: output
            'ABA', 
            'BCB', // arg 2: the shape (array of strings)
            'ABA'  
          ], {
            A: 'minecraft:redstone',
            B: 'gtceu:certus_quartz_gem',
            C: '#gtceu:circuits/hv'
          }
        )
    event.shaped('ae2:cell_component_64k', [// arg 1: output
            'ABA', 
            'BCB', // arg 2: the shape (array of strings)
            'ABA'  
          ], {
            A: 'minecraft:redstone',
            B: 'gtceu:certus_quartz_gem',
            C: '#gtceu:circuits/ev'
          }
        )
    event.shaped('ae2:cell_component_256k', [// arg 1: output
            'ABA', 
            'BCB', // arg 2: the shape (array of strings)
            'ABA'  
          ], {
            A: 'minecraft:redstone',
            B: 'gtceu:certus_quartz_gem',
            C: '#gtceu:circuits/iv'
          }
        )
    event.shaped('ae2:drive', [// arg 1: output
            'ABA', 
            'C C', // arg 2: the shape (array of strings)
            'ABA'  
          ], {
            A: 'gtceu:platinum_ingot',
            B: '#gtceu:circuits/hv',
            C: 'enderio:me_conduit'
          }
        )
    event.shaped('ad_astra:nasa_workbench', [// arg 1: output
          'ABA', 
          'CDC', // arg 2: the shape (array of strings)
          'EFE'  
        ], {
          A: 'gtceu:steel_frame',
          E: '#gtceu:circuits/ev',
          B: 'gtceu:platinum_single_wire',
          C: 'gtceu:double_steel_plate',
          D: 'gtceu:kanthal_coil_block',
          F: 'gtceu:steel_block'
        }
      )

    ////// Machine Recipe //////

    event.shaped(
        'gtceu:moonminer',
        ['AWA', 'CSC', 'WCW'],
        {
            A: '#gtceu:circuits/ev',
            W: 'ad_astra:desh_block',
            C: '#gtceu:circuits/ev',
            S: 'ad_astra:moon_globe'
        }
    ).id('gtceu:shaped/moonminer')
  

    event.recipes.gtceu.distillery('fuelastra')
        .circuit(5)
        .inputFluids('gtceu:diesel 1000')
        .outputFluids('ad_astra:fuel 250')
        .duration(2000)
        .EUt(24)
    event.recipes.gtceu.alloy_smelter('neodymium')
        .itemInputs('8x gtceu:potin_dust', '4x gtceu:stainless_steel_dust')
        .itemOutputs('4x gtceu:neodymium_dust')
        .duration(120)
        .EUt(24)

      event.shaped(
          'ae2:crafting_unit',
          ['AWA', 'CSC', 'AWA'],
          {
              A: 'gtceu:titanium_ingot',
              W: 'gtceu:cpu_chip',
              C: 'enderio:dense_me_conduit',
              S: '#gtceu:circuits/hv'
          }
      ).id('ae2:unit')
      event.shaped(
        'ae2:pattern_provider',
        ['AWA', 'C C', 'AWA'],
        {
            A: 'gtceu:titanium_ingot',
            W: 'gtceu:cpu_chip',
            C: 'enderio:dense_me_conduit'
        }
      ).id('ae2:patternprov')
      event.shaped(
        'ae2:molecular_assembler',
        ['AWA', 'C C', 'AWA'],
        {
            A: 'gtceu:titanium_ingot',
            W: 'gtceu:cpu_chip',
            C: 'solarflux:photovoltaic_cell_1'
        }
      ).id('ae2:molecularasse')
      event.recipes.gtceu.cutter('mirror')
          .itemInputs('gtceu:tempered_glass')
          .inputFluids('gtceu:distilled_water 250')
          .itemOutputs('32x solarflux:mirror')
          .duration(220)
          .EUt(512)
      event.recipes.gtceu.assembler('pattern')
          .itemInputs('8x solarflux:mirror', 'gtceu:aluminium_ingot', 'ae2:calculation_processor')
          .inputFluids('gtceu:lubricant 63')
          .itemOutputs('8x ae2:blank_pattern')
          .duration(60)
          .EUt(2048)
      event.recipes.gtceu.alloy_smelter('skystonedust')
          .itemInputs('ae2:fluix_crystal', 'gtceu:stone_dust')
          .itemOutputs('ae2:sky_dust')
          .duration(60)
          .EUt(32)
      event.recipes.gtceu.mixer('fluorine')
          .itemInputs('64x gtceu:sulfur_dust')
          .inputFluids('minecraft:water 1000')
          .outputFluids('gtceu:fluorine 6000')
          .duration(60)
          .EUt(32)
      event.recipes.gtceu.centrifuge('rocksalt')
          .itemInputs('32x gtceu:sulfur_dust')
          .itemOutputs("8x gtceu:rock_salt_dust")
          .duration(100)
          .EUt(32)
        exdeorum.setCrucibleHeatValueForState('minecraft:lightning_rod', 80);
      event.recipes.gtceu.centrifuge('molybdenum')
          .itemInputs('16x minecraft:ender_eye')
          .itemOutputs('gtceu:molybdenum_dust')
          .duration(300)
          .EUt(32)
      event.recipes.gtceu.mixer('tungstate')
          .itemInputs('16x gtceu:steel_ingot', '16x gtceu:vanadium_steel_dust', '64x gtceu:sulfur_dust', 'gtceu:raw_styrene_butadiene_rubber_dust')
          .itemOutputs('gtceu:tungsten_dust')
          .duration(600)
          .EUt(32)
      event.recipes.gtceu.centrifuge('ruthenium')
          .itemInputs("gtceu:diamond_dust")
          .itemOutputs("gtceu:ruthenium_dust")
          .duration(400)
          .EUt(32)
      event.shaped(
            'gtceu:fluid_filter',
            ['AAA', 'AWA', 'AAA'],
            {
                A: 'gtceu:steel_foil',
                W: 'minecraft:water_bucket'
            }
          ).id('gtceu:filterfluid')
      event.recipes.gtceu.arc_furnace('platinumsludge')
          .itemInputs('gtceu:platinum_dust')
          .inputFluids('gtceu:nitric_acid 1000')
          .itemOutputs('4x gtceu:platinum_group_sludge_dust')
          .duration(120)
          .EUt(8192)
      event.shaped(
            'gtceu:starextractor',
            ['AWA', 'CSC', 'WCW'],
            {
                A: '#gtceu:circuits/iv',
                W: 'gtceu:polybenzimidazole_plate',
                C: '#gtceu:circuits/iv',
                S: 'gtceu:iridium_frame'
            }
        ).id('gtceu:shaped/starextractor')
    event.recipes.gtceu.alloy_smelter('marble')
        .itemInputs("gtceu:calcite_dust", 'exdeorum:compressed_cobblestone')
        .itemOutputs("gtceu:marble")
        .duration(4000)
        .EUt(32)
    event.recipes.gtceu.alloy_smelter('galliumarsenide')
        .itemInputs('gtceu:arsenic_dust', 'gtceu:gallium_dust')
        .itemOutputs('gtceu:gallium_arsenide_dust')
        .duration(4000)
        .EUt(32)
    event.recipes.gtceu.centrifuge('mattercentrifuge')
        .inputFluids('gtceu:star_matter 100')
        .itemOutputsRanged('gtceu:raw_beryllium', 1, 10)
        .itemOutputsRanged('gtceu:raw_apatite', 10, 60)
        .itemOutputsRanged('gtceu:raw_mica', 1, 10)
        .itemOutputsRanged('gtceu:raw_oilsands', 15, 90)
        .itemOutputsRanged('gtceu:raw_amethyst', 10, 60)
        .itemOutputsRanged('gtceu:indium_dust', 2, 4)
        .outputFluids('gtceu:tantalum_carbide 500')
        .duration(4000)
        .EUt((GTValues.VA[GTValues.HV]))
    event.recipes.gtceu.electrolyzer('sodiumhydroxide')
        .inputFluids([Fluid.of('gtceu:mercury', 1000)])
        .outputFluids([Fluid.of('gtceu:mercury_vapor', 250)])
        .itemOutputsRanged('gtceu:sodium_hydroxide_dust', 2, 15)
        .duration(2000)
        .EUt((GTValues.VA[GTValues.LV]))
    event.recipes.gtceu.combustion_generator('mercurypower')
        .notConsumable('gtceu:quantum_star')
        .inputFluids(Fluid.of('gtceu:mercury_vapor', 1000))
        .duration(400).EUt(-(GTValues.V[GTValues.IV]))
    event.recipes.gtceu.autoclave('starmold')
        .inputFluids(Fluid.of('gtceu:star_matter', 144))
        .itemInputs('gtceu:empty_mold')
        .itemOutputs('kubejs:star_extruder_mold')
        .duration(2000)
        .EUt((GTValues.VA[GTValues.IV]))
    event.recipes.gtceu.autoclave('nether_star')
        .inputFluids(Fluid.of('gtceu:star_matter', 144))
        .notConsumable('kubejs:star_extruder_mold')
        .itemOutputs('minecraft:nether_star')
        .duration(20)
        .EUt((GTValues.VA[GTValues.LuV]))
    event.recipes.gtceu.forming_press('flux_dust')
        .itemInputs('2x minecraft:redstone', "minecraft:obsidian")
        .notConsumable('extendedcrafting:nether_star_block')
        .itemOutputs('fluxnetworks:flux_dust')
        .duration(500)
        .EUt((GTValues.VA[GTValues.HV]))
    event.recipes.gtceu.chemical_reactor('raw_life_essence')
        .itemInputs('16x minecraft:rotten_flesh')
        .inputFluids(Fluid.of('gtceu:nitric_acid 1000'))
        .outputFluids('gtceu:raw_life_essence 3000')
        .duration(200)
        .EUt((GTValues.VA[GTValues.IV]))
    event.recipes.gtceu.mixer('inert_life_essence')
        .itemInputs('3x gtceu:epoxy_dust')
        .inputFluids(Fluid.of('gtceu:raw_life_essence 3000'))
        .outputFluids('gtceu:inert_life_essence 3000')
        .duration(200)
        .EUt((GTValues.VA[GTValues.IV]))
    event.shaped(
        'bloodmagic:altar',
        ['A A', 'AWA', 'CCC'],
        {
            A: 'gtceu:indium_gallium_phosphide_ingot',
            W: '#gtceu:circuits/luv',
            C: 'gtceu:dense_rhodium_plated_palladium_plate'
        }
        ).id('bm:altar')
    event.recipes.gtceu.chemical_bath('processed_life_essence')
        .notConsumable('bloodmagic:weakbloodorb')
        .inputFluids(Fluid.of('gtceu:inert_life_essence 3000'))
        .outputFluids('gtceu:processed_life_essence 3000')
        .duration(200)
        .EUt((GTValues.VA[GTValues.IV]))
    event.recipes.gtceu.chemical_reactor('life_essence')
        .notConsumable('bloodmagic:weakbloodorb')
        .inputFluids(Fluid.of('gtceu:processed_life_essence 3000'))
        .inputFluids(Fluid.of('gtceu:oxygen 1000'))
        .outputFluids('bloodmagic:life_essence_fluid 7000')
        .duration(200)
        .EUt((GTValues.VA[GTValues.IV]))
    event.recipes.gtceu.assembler('advancedtable')
        .itemInputs('avaritia:double_compressed_crafting_table', 'gtceu:luv_machine_casing', '8x extendedcrafting:luminessence')
        .inputFluids(Fluid.of('gtceu:polybenzimidazole 266'))
        .itemOutputs('extendedcrafting:advanced_table')
        .duration(500)
        .EUt(4)
    event.recipes.gtceu.forming_press('earth_globe')
        .itemInputs(['64x exdeorum:compressed_diorite', '64x exdeorum:compressed_cobblestone', '64x exdeorum:compressed_granite', '64x exdeorum:compressed_andesite', '64x exdeorum:compressed_gravel'])
        .notConsumable('extendedcrafting:nether_star_block')
        .itemOutputs('ad_astra:earth_globe')
        .duration(500)
    event.shaped(
            'angelring:angel_ring',
            ['A A', 'AWA', 'CCC'],
            {
                A: 'gtceu:manganese_phosphide_ingot',
                W: 'gtceu:lv_field_generator',
                C: 'gtceu:double_platinum_plate'
            }
            ).id('ag:angel_ring')
    event.recipes.gtceu.assembler('mars_globe')
            .itemInputs('ad_astra:earth_globe', 'ad_astra:ostrum_block', '16x gtceu:cobalt_brass_ingot')
            .inputFluids(Fluid.of('gtceu:polybenzimidazole 266'))
            .itemOutputs('ad_astra:mars_globe')
            .duration(500)
            .EUt((GTValues.VA[GTValues.LuV]))
    event.recipes.gtceu.chemical_bath('meat')
            .itemInputs('16x minecraft:rotten_flesh')
            .inputFluids(Fluid.of('bloodmagic:life_essence_fluid 16000'))
            .itemOutputs('minecraft:porkchop')
            .duration(500)
            .EUt((GTValues.VA[GTValues.HV]))
    event.recipes.gtceu.electric_blast_furnace('gtceu:ebf/resonant_naquadah')
            .itemInputs('gtceu:resonant_naquadah_dust')
            .inputFluids('gtceu:krypton 1000')
            .itemOutputs('gtceu:resonant_naquadah_ingot')
            .blastFurnaceTemp(9001)
            .duration(1400)
            .EUt(GTValues.VA[GTValues.UV]);
    event.recipes.gtceu.fusion_reactor('darmastadium')
            .inputFluids('gtceu:resonant_naquadah 16', 'gtceu:ruthenium 16')
            .outputFluids('gtceu:darmstadtium 32')
            .fusionStartEU(200000000)
            .duration(30)
            .EUt((GTValues.VA[GTValues.LuV]))
    event.recipes.gtceu.autoclave('sky_steel')
            .inputFluids(Fluid.of('gtceu:iron', 144))
            .itemInputs('gtceu:certus_quartz_gem', 'ae2:sky_dust')
            .itemOutputs('megacells:sky_steel_ingot')
            .duration(20)
            .EUt((GTValues.VA[GTValues.HV]))
    event.recipes.gtceu.circuit_assembler('accuprocess')
            .itemInputs('ae2:silicon', 'minecraft:redstone', 'megacells:sky_steel_ingot')
            .inputFluids('gtceu:lubricant 63')
            .notConsumable('ae2:name_press')
            .itemOutputs('megacells:accumulation_processor')
            .duration(40)
            .EUt(128)
            event.shapeless('minecraft:egg', [ 'minecraft:grass', 'hostilenetworks:overworld_prediction'])
    event.recipes.gtceu.bender('deshplate')
            .itemInputs('ad_astra:desh_ingot')
            .itemOutputs('ad_astra:desh_plate')
            .circuit(1)
            .duration(40)
            .EUt(128)
        event.shaped(
            'gtceu:altart2',
            ['ABA', 'CZC', 'AFA'],
            {
                A: 'gtceu:dense_rhodium_plated_palladium_plate',
                B: 'gtceu:hsss_frame',
                C: '#gtceu:circuits/luv',
                Z: 'bloodmagic:altar',
                F: 'megacells:bulk_cell_component'
           }
            ).id('bm:altart2')




          
        

        })