
ServerEvents.recipes(event => {

event.recipes.gtceu.assembly_line('tier2rocket')
    .itemInputs(['gtceu:luv_field_generator', '64x ad_astra:desh_block', '9x gtceu:nether_star_plate', '64x ad_astra:desh_engine', '#gtceu:circuits/zpm', '2x gtceu:niobium_titanium_quadruple_cable'])
    .itemOutputs('ad_astra:tier_2_rocket')
    .inputFluids(
      Fluid.of('gtceu:star_matter', 576),
      Fluid.of('gtceu:silicone_rubber', 1152),
      Fluid.of('gtceu:styrene_butadiene_rubber', 1152),
      Fluid.of('gtceu:soldering_alloy', 1152),
    )
  ["scannerResearch(java.util.function.UnaryOperator)"](b => b.researchStack(Item.of('ad_astra:tier_1_rocket')).EUt(GTValues.VA[GTValues.IV]).duration(1000))
    .duration(3000)
    .EUt(GTValues.VA[GTValues.LuV])

})