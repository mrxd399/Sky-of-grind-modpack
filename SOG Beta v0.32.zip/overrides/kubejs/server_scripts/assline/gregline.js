
ServerEvents.recipes(event => {

    event.recipes.gtceu.assembly_line('naquadahmk1')
        .itemInputs('3x gtceu:zpm_field_generator', '8x gtceu:resonant_naquadah_spring', '64x gtceu:nether_star_plate', '#gtceu:circuits/uv', '2x gtceu:resonant_naquadah_hex_wire', 'gtceu:luv_fusion_reactor')
        .itemOutputs('gtceu:naquadahreactormk1')
        .inputFluids(
          Fluid.of('gtceu:star_matter', 5950),
          Fluid.of('gtceu:silicone_rubber', 1152),
          Fluid.of('gtceu:styrene_butadiene_rubber', 1152),
          Fluid.of('gtceu:soldering_alloy', 1152),
        )
        .stationResearch(b => b.researchStack(Item.of('gtceu:naquadah_boule')).EUt(GTValues.VA[GTValues.UV]).CWUt(96)) // 
        .duration(3000)
        .EUt(GTValues.VA[GTValues.UV])

    event.recipes.gtceu.assembly_line('ae2energy')
        .itemInputs('gtceu:uv_machine_hull', '64x gtceu:advanced_computer_casing', '64x gtceu:computation_receiver_hatch', '64x gtceu:advanced_computer_casing', '64x gtceu:neutron_reflector', '32x gtceu:double_tritanium_plate', '64x gtceu:zpm_parallel_hatch', 'megacells:mega_energy_cell', 'megacells:cell_component_256m')
        .itemOutputs('ae2:creative_energy_cell')
        .inputFluids(
          Fluid.of('gtceu:star_matter', 5950),
          Fluid.of('gtceu:silicone_rubber', 1152),
          Fluid.of('gtceu:styrene_butadiene_rubber', 1152),
          Fluid.of('gtceu:resonant_naquadah', 10152),
        )
        .stationResearch(b => b.researchStack(Item.of('megacells:cell_component_256m')).EUt(GTValues.VA[GTValues.UV]).CWUt(328)) // 
        .duration(30000)
        .EUt(GTValues.VA[GTValues.UV])
        
    
    })