
ServerEvents.recipes(event => {

event.recipes.gtceu.moonminer('titaminer')
    .notConsumable('ad_astra:moon_globe')
    .inputFluids([Fluid.of('gtceu:drilling_fluid', 1000)])
    .itemOutputs('gtceu:hot_titanium_ingot')
    .biome('ad_astra:lunar_wastelands')
    .duration(640)
    .EUt(GTValues.VA[GTValues.EV]);

event.recipes.gtceu.starextractor('star_matter')
    .notConsumable('gtceu:quantum_eye')
    .inputFluids([Fluid.of('gtceu:drilling_fluid', 1000)])
    .outputFluids([Fluid.of('gtceu:mercury 1000')])
    .itemOutputs('1x gtceu:star_matter_nugget')
    .biome('ad_astra:orbit')
    .duration(640)
    .EUt(GTValues.VA[GTValues.IV]);

event.recipes.gtceu.altart2('magicianorb')
    .inputFluids([Fluid.of('bloodmagic:life_essence_fluid', 20000)])
    .itemInputs('bloodmagic:weakbloodorb')
    .itemOutputs('bloodmagic:magicianbloodorb')
    .duration(3000)
    .EUt(GTValues.VA[GTValues.LuV]);
event.recipes.gtceu.altart2('largebloodbrick')
    .inputFluids([Fluid.of('bloodmagic:life_essence_fluid', 20000)])
    .itemInputs('minecraft:stone_bricks')
    .itemOutputs('4x bloodmagic:largebloodstonebrick')
    .duration(100)
    .EUt(GTValues.VA[GTValues.LuV]);
event.recipes.gtceu.altart3('demoniteblock')
    .inputFluids([Fluid.of('bloodmagic:life_essence_fluid', 10000)])
    .itemInputs('extendedcrafting:crystaltine_ingot')
    .itemOutputs('2x bloodmagic:dungeon_metal')
    .duration(400)
    .EUt(GTValues.VA[GTValues.LuV]);
event.recipes.gtceu.altart4('demoniteblock4')
    .inputFluids([Fluid.of('bloodmagic:life_essence_fluid', 10000)])
    .itemInputs('extendedcrafting:crystaltine_ingot')
    .itemOutputs('2x bloodmagic:dungeon_metal')
    .duration(300)
    .EUt(GTValues.VA[GTValues.LuV]);
event.recipes.gtceu.altart5('demoniteblock5')
    .inputFluids([Fluid.of('bloodmagic:life_essence_fluid', 10000)])
    .itemInputs('extendedcrafting:crystaltine_ingot')
    .itemOutputs('2x bloodmagic:dungeon_metal')
    .duration(100)
    .EUt(GTValues.VA[GTValues.LuV]);
event.recipes.gtceu.altart4('arcmagebloodorb')
    .inputFluids([Fluid.of('bloodmagic:life_essence_fluid', 20000)])
    .itemInputs('bloodmagic:magicianbloodorb')
    .itemOutputs('bloodmagic:archmagebloodorb')
    .duration(3000)
    .EUt(GTValues.VA[GTValues.LuV]);
event.recipes.gtceu.altart5('pylon')
    .inputFluids([Fluid.of('bloodmagic:life_essence_fluid', 40000)])
    .itemInputs('bloodmagic:demoncrystallizer')
    .itemOutputs('bloodmagic:demonpylon')
    .duration(1500)
    .EUt(GTValues.VA[GTValues.LuV]);
event.recipes.gtceu.altart6('pyrochlore')
    .notConsumable('ad_astra:earth_globe')
    .inputFluids([Fluid.of('bloodmagic:life_essence_fluid', 256000)])
    .itemOutputsRanged('gtceu:raw_pyrochlore', 256, 512)
    .itemOutputsRanged('gtceu:raw_apatite', 256, 512)
    .itemOutputsRanged('gtceu:raw_tricalcium_phosphate', 256, 512)
    .circuit(1)
    .duration(3000)
    .EUt(GTValues.VA[GTValues.LuV]);
event.recipes.gtceu.altart6('meteoroverworld')
    .notConsumable('ad_astra:earth_globe')
    .inputFluids([Fluid.of('bloodmagic:life_essence_fluid', 512000)])
    .itemInputs('64x bloodmagic:dungeon_metal')
    .itemOutputsRanged('gtceu:raw_nickel', 500, 4500)
    .itemOutputsRanged('gtceu:raw_graphite', 500, 4500)
    .itemOutputsRanged('gtceu:raw_coal', 500, 4500)
    .itemOutputsRanged('gtceu:raw_diamond', 500, 4500)
    .itemOutputsRanged('gtceu:raw_lapis', 500, 4500)
    .itemOutputsRanged('gtceu:raw_redstone', 500, 4500)
    .itemOutputsRanged('minecraft:raw_copper', 500, 4500)
    .itemOutputsRanged('minecraft:raw_gold', 500, 4500)
    .itemOutputsRanged('minecraft:raw_iron', 500, 4500)
    .itemOutputsRanged('gtceu:raw_tin', 500, 4500)
    .itemOutputsRanged('gtceu:raw_amethyst', 500, 4500)
    .itemOutputsRanged('gtceu:raw_green_sapphire', 500, 4500)
    .itemOutputsRanged('gtceu:raw_sphalerite', 500, 4500)
    .itemOutputsRanged('gtceu:raw_apatite', 500, 4500)
    .itemOutputsRanged('gtceu:raw_cobaltite', 500, 4500)
    .itemOutputsRanged('gtceu:raw_certus_quartz', 500, 4500)
    .itemOutputsRanged('gtceu:raw_quartzite', 500, 4500)
    .itemOutputsRanged('gtceu:raw_salt', 500, 4500)
    .itemOutputsRanged('gtceu:raw_saltpeter', 500, 4500)
    .itemOutputsRanged('gtceu:raw_beryllium', 500, 4500)
    .itemOutputsRanged('gtceu:raw_lead', 500, 4500)
    .itemOutputsRanged('gtceu:raw_silver', 500, 4500)
    .itemOutputsRanged('gtceu:raw_barite', 500, 4500)
    .itemOutputsRanged('gtceu:raw_stibnite', 500, 4500)
    .itemOutputsRanged( 'gtceu:raw_kyanite', 500, 4500)
    .itemOutputsRanged( 'gtceu:raw_emerald', 500, 4500)
    .outputFluids('gtceu:oil 100000')
    .outputFluids('gtceu:natural_gas 50000')
    .outputFluids('minecraft:lava 2500000')
    .circuit(2)
    .duration(6000)
    .EUt(GTValues.VA[GTValues.LuV]);

event.recipes.gtceu.altart6('meteormoon')
    .notConsumable('ad_astra:moon_globe')
    .inputFluids([Fluid.of('bloodmagic:life_essence_fluid', 512000)])
    .itemInputs('64x bloodmagic:dungeon_metal')
    .itemOutputsRanged('ad_astra:raw_desh', 500, 4500)
    .itemOutputsRanged('gtceu:star_matter_nugget', 1, 10)
    .itemOutputsRanged('gtceu:rare_earth_dust', 500, 4500)
    .itemOutputsRanged('gtceu:borax_dust', 500, 4500)
    .outputFluids('gtceu:titanium 144000')
    .outputFluids('gtceu:helium 50000')
    .outputFluids('gtceu:nitrogen 2500000')
    .circuit(2)
    .duration(6000)
    .EUt(GTValues.VA[GTValues.LuV]);

event.recipes.gtceu.altart6('meteormars')
    .notConsumable('ad_astra:mars_globe')
    .inputFluids([Fluid.of('bloodmagic:life_essence_fluid', 512000)])
    .itemInputs('64x bloodmagic:dungeon_metal')
    .itemOutputsRanged('ad_astra:raw_ostrum', 500, 4500)
    .itemOutputsRanged('gtceu:star_matter_nugget', 1, 10)
    .itemOutputsRanged('gtceu:raw_naquadah', 500, 4500)
    .itemOutputsRanged('gtceu:antimony_trifluoride_dust', 500, 4500)
    .itemOutputsRanged('minecraft:netherite_scrap', 500, 4500)
    .itemOutputsRanged('gtceu:raw_plutonium', 500, 4500)
    .outputFluids('gtceu:natural_gas 144000')
    .outputFluids('gtceu:deuterium 50000')
    .outputFluids('gtceu:nitrogen 2500000')
    .circuit(2)
    .duration(6000)
    .EUt(GTValues.VA[GTValues.LuV]);

event.recipes.gtceu.altart2('altart3recipe')
    .inputFluids([Fluid.of('bloodmagic:life_essence_fluid', 200000)])
    .itemInputs('gtceu:altart2')
    .itemOutputs('gtceu:altart3')
    .duration(3000)
    .EUt(GTValues.VA[GTValues.LuV]);

event.recipes.gtceu.altart3('altart4recipe')
    .inputFluids([Fluid.of('bloodmagic:life_essence_fluid', 200000)])
    .itemInputs('gtceu:altart3')
    .itemOutputs('gtceu:altart4')
    .duration(3000)
    .EUt(GTValues.VA[GTValues.LuV]);
    
event.recipes.gtceu.altart4('altart5recipe')
    .inputFluids([Fluid.of('bloodmagic:life_essence_fluid', 200000)])
    .itemInputs('gtceu:altart4')
    .itemOutputs('gtceu:altart5')
    .duration(3000)
    .EUt(GTValues.VA[GTValues.LuV]);

event.recipes.gtceu.altart5('altart5recipe')
    .inputFluids([Fluid.of('bloodmagic:life_essence_fluid', 200000)])
    .itemInputs('gtceu:altart5')
    .itemOutputs('gtceu:altart6')
    .duration(30000)
    .EUt(GTValues.VA[GTValues.LuV]);









})