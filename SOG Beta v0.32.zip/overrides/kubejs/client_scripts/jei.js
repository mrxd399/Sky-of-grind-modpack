// priority: 0

// Visit the wiki for more info - https://kubejs.com/

console.info('Hello, World! (Loaded client scripts)')

JEIEvents.hideItems(event => {

  //AdAstra
  event.hide([Item.of('ad_astra:hammer', '{Damage:0}')])
  event.hide(['ad_astra:coal_generator', 'ad_astra:compressor', 'ad_astra:oxygen_distributor', 'ad_astra:fuel_refinery', 'ad_astra:iron_plate', 'ad_astra:steel_ingot', 'ad_astra:steel_plate', 'ad_astra:iron_rod'])
  //Furnaces
  event.hide(['ironfurnaces:upgrade_silver', 'ironfurnaces:upgrade_obsidian2', 'ironfurnaces:upgrade_iron2', 'ironfurnaces:upgrade_gold2', 'ironfurnaces:upgrade_silver2', 'ironfurnaces:upgrade_iron', 'ironfurnaces:upgrade_gold', 'ironfurnaces:upgrade_diamond', 'ironfurnaces:upgrade_emerald', 'ironfurnaces:upgrade_obsidian', 'ironfurnaces:upgrade_crystal', 'ironfurnaces:upgrade_netherite', 'ironfurnaces:upgrade_copper', 'ironfurnaces:upgrade_silver'])
  event.hide(['ironfurnaces:rainbow_core', 'ironfurnaces:rainbow_plating', 'ironfurnaces:rainbow_coal', 'ironfurnaces:augment_speed', 'ironfurnaces:augment_generator'])
  //Drawers
  event.hide(['functionalstorage:copper_upgrade', 'functionalstorage:gold_upgrade', 'functionalstorage:diamond_upgrade', 'functionalstorage:netherite_upgrade'])
  event.hide(['functionalstorage:puller_upgrade', 'functionalstorage:collector_upgrade', 'functionalstorage:pusher_upgrade'])
  //deorum
  event.hide([['exdeorum:oak_compressed_sieve', 'exdeorum:birch_compressed_sieve', 'exdeorum:spruce_compressed_sieve', 'exdeorum:jungle_compressed_sieve', 'exdeorum:acacia_compressed_sieve', 'exdeorum:dark_oak_compressed_sieve', 'exdeorum:mangrove_compressed_sieve', 'exdeorum:cherry_compressed_sieve', 'exdeorum:bamboo_compressed_sieve', 'exdeorum:mechanical_sieve', 'exdeorum:mechanical_hammer', 'exdeorum:crimson_compressed_sieve', 'exdeorum:warped_compressed_sieve']])
  event.hide(['exdeorum:oak_sieve', 'exdeorum:spruce_sieve', 'exdeorum:birch_sieve', 'exdeorum:jungle_sieve', 'exdeorum:acacia_sieve', 'exdeorum:dark_oak_sieve', 'exdeorum:mangrove_sieve', 'exdeorum:cherry_sieve', 'exdeorum:bamboo_sieve', 'exdeorum:warped_sieve', 'exdeorum:crimson_sieve'])
  //endertanks
  event.hide(['enderchests:ender_pouch', 'enderchests:ender_bag', 'endertanks:ender_bucket'])
  //ae2
  event.hide([['expatternprovider:ex_inscriber', 'megacells:mega_interface', 'expatternprovider:ex_charger', 'megacells:cable_mega_pattern_provider', 'megacells:mega_pattern_provider', 'megacells:cable_mega_interface']])
  event.hide(['ae2:certus_quartz_crystal', 'ae2:charged_certus_quartz_crystal', 'ae2:certus_quartz_dust', 'ae2:inscriber', 'ae2:charger'])
  //avaritia
  event.hide(['avaritia:extreme_crafting_table', 'avaritia:infinity_block', 'avaritia:diamond_lattice', 'avaritia:infinity_ingot', 'avaritia:iron_singularity', 'avaritia:golden_singularity', 'avaritia:lapis_singularity', 'avaritia:redstone_singularity', 'avaritia:nether_quartz_singularity', 'avaritia:netherite_singularity', 'avaritia:amethyst_singularity', 'avaritia:copper_singularity', 'avaritia:emerald_singularity', 'avaritia:diamond_singularity'])
  event.hide(['avaritia:crystal_matrix_ingot', 'avaritia:crystal_matrix'])




})



onEvent('jei.remove.categories', event => {
  event.remove('ae2:inscriber')
  event.remove('ae2:charger')
  event.remove('ae2:transform')
})