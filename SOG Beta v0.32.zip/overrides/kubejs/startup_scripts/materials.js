GTCEuStartupEvents.registry('gtceu:element', event => {
    event.create('infinity', Infinity, Infinity, -1, null, '∞', false);
})

GTCEuStartupEvents.registry('gtceu:material_icon_set', event => {
    event.create('infinity').parent(GTMaterialIconSet.SHINY)
})




GTCEuStartupEvents.registry('gtceu:material', event => {
    event.create('star_matter')
        .ingot().fluid()
        .color(0xd9ddfc)
    event.create('mercury_vapor')
        .fluid()
        .color(0xd7d7db)
    event.create('inert_life_essence')
        .fluid()
        .color(0xe0bcc3)
    event.create('raw_life_essence')
        .liquid()
        .color(0xa8979a)
    event.create('processed_life_essence')
        .liquid()
        .color(0xff7878)
    event.create('processed_naquadria_sulfate')
        .liquid()
        .color(0x82ff82)
    event.create('acidic_processed_naquadria_sulfate')
        .liquid()
        .color(0xc5ff82)
    event.create('acidic_naquadria_fuel_solution')
        .liquid()
        .color(0xc5ff82)
    event.create('impure_naquadria_fuel')
        .liquid()
        .color(0x6d9c76)
    event.create('pure_naquadria_fuel')
        .liquid()
        .color(0x426148)
    event.create('naquadria_plasma')
        .plasma()
        .color(0x426148)
    event.create('resonant_naquadah')
        .ingot().fluid().dust()
        .color(0x2b3d2d)
        .blastTemp(9100) 
        .cableProperties(GTValues.V[GTValues.UV], 4, 2, true)
        .iconSet(GTMaterialIconSet.SHINY)
        .flags(
            GTMaterialFlags.GENERATE_PLATE,
            GTMaterialFlags.GENERATE_BOLT_SCREW,
            GTMaterialFlags.GENERATE_ROD,
            GTMaterialFlags.GENERATE_SPRING,
            GTMaterialFlags.GENERATE_SPRING_SMALL,
            GTMaterialFlags.GENERATE_FOIL,
            GTMaterialFlags.NO_SMELTING,
            GTMaterialFlags.NO_ORE_SMELTING

        )
        event.create("crystal_matrix")
        .ingot().fluid()
        .color(0x66ffff)
        .iconSet('shiny')
        .fluidPipeProperties(100000, 64000, true, true, true, true)
        .flags(GTMaterialFlags.GENERATE_PLATE, GTMaterialFlags.GENERATE_FOIL, GTMaterialFlags.GENERATE_ROD, GTMaterialFlags.GENERATE_FRAME, GTMaterialFlags.GENERATE_ROTOR, GTMaterialFlags.GENERATE_DENSE);
        event.create('infinity')
        .ingot()
        .element(GTElements.get("infinity"))
        .color(0xffffff)
        .iconSet('infinity')
        .flags(GTMaterialFlags.GENERATE_PLATE, GTMaterialFlags.GENERATE_ROD,  GTMaterialFlags.GENERATE_LONG_ROD, GTMaterialFlags.GENERATE_RING, GTMaterialFlags.GENERATE_ROUND, GTMaterialFlags.GENERATE_GEAR, GTMaterialFlags.GENERATE_SMALL_GEAR, GTMaterialFlags.GENERATE_BOLT_SCREW, GTMaterialFlags.GENERATE_FRAME, GTMaterialFlags.GENERATE_DENSE)
})