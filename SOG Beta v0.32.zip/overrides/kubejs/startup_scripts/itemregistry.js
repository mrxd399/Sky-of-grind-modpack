
StartupEvents.registry('item', event => {

event.create('star_extruder_mold').maxStackSize(64).glow(true).displayName('Extruder Mold (Star)')
event.create('resonant_reinforced_printed_circuit').maxStackSize(64).displayName('Resonant-Reinforced Printed Circuit Board')



})

StartupEvents.registry('block', event => {


    event.create('neutronate_enriched_atomic_casing')
        .displayName('Neutronate Enriched Atomic Casing')
        .textureAll('kubejs:block/atomic/casing')
        .soundType('metal')
        .resistance(1)
        .lightLevel(0)
        .tagBlock('mineable:pickaxe')
})