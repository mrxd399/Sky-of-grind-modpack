/// <reference path="./globals.d.ts" />
const Direction: typeof Facing
const Vec3f: typeof Vector3f
const Component: typeof Text
